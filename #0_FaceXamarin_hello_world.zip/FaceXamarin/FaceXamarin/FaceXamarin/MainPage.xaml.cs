﻿using Plugin.Media;
using Plugin.Media.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Diagnostics;
using Xamarin.Forms;
using XFShapeView;

namespace FaceXamarin
{
    /// <summary>
    /// 이미지 파일 선택해서 가져오기 : https://github.com/jamesmontemagno/MediaPlugin
    /// 도형 그리기 : https://github.com/vincentgury/XFShapeView
    /// </summary>
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        //private async void Button_OnClicked(object sender, EventArgs e)
        //{

        //}
    }
}